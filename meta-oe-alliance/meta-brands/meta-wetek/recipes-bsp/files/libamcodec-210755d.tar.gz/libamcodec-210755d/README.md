libamplayer-m3
==============

--fixed git history
forked from stane1983

