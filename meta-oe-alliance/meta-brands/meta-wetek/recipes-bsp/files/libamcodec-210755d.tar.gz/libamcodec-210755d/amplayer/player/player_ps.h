#ifndef _PLAYER_PS_H_
#define _PLAYER_PS_H_

int ps_register_stream_decoder(void);

#endif
