#ifndef AMAUDIO_UTILS_H
#define AMAUDIO_UTILS_H

#ifdef  __cplusplus
extern "C" {
#endif


#ifdef  __cplusplus
}
#endif


#endif
